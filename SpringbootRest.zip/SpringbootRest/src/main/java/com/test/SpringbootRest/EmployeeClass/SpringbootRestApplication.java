package com.test.SpringbootRest.EmployeeClass;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.test.SpringbootRest.EmployeeClass.EmployeeRepository.AppUser;
import com.test.SpringbootRest.EmployeeClass.EmployeeRepository.AppUserService;

@SpringBootApplication
public class SpringbootRestApplication implements CommandLineRunner{

	@Autowired
	AppUserService userdataservice;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringbootRestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Set<String> authadmin=new HashSet();
		authadmin.add("admin");
		 
		Set<String> authuser=new HashSet();
		authuser.add("user");
		
		PasswordEncoder en=new BCryptPasswordEncoder();
		
		AppUser useradmin=new AppUser(1,"admin",en.encode("2307"),authadmin);
		userdataservice.add(useradmin);
		
		AppUser user=new AppUser(2,"user",en.encode("2002"),authuser);
		userdataservice.add(user);
	}

}

