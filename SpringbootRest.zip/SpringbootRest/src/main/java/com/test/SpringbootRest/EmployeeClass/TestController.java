package com.test.SpringbootRest.EmployeeClass;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.SpringbootRest.EmployeeClass.EmployeeRepository.Employee;
import com.test.SpringbootRest.EmployeeClass.EmployeeRepository.EmployeeService;
import com.test.SpringbootRest.EmployeeClass.EmployeeRepository.AppUserService;

@RestController
public class TestController {
	
	@Autowired
	EmployeeService employeeservice;
	
	@Autowired
	AppUserService userservice;
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/viewemployee")
	public List<Employee> view(Authentication authentication,SecurityContextHolder auth) {
		 
		String accept="user";
		boolean found=false;
		
		System.out.println("login:"+authentication.getName());
		
		Collection<?extends GrantedAuthority> roles=auth.getContext().getAuthentication().getAuthorities();
		
		for(GrantedAuthority temp:roles) {
			String role =temp.toString();
			System.out.println("role........"+role);
			
			if(role.equalsIgnoreCase(accept)) {
				found=true;
			}
			
		}
		if(found) {
			List<Employee> employeelist=employeeservice.getall();
			return employeelist;
		}
		else {
			return null;
		}
	}
	
	@PostMapping("/addemployee")
	public String add(@RequestParam int id,@RequestParam String name,@RequestParam String jobRole,@RequestParam int phNumber,Authentication authentication,SecurityContextHolder auth) {
		 
		String accept="admin";
		boolean found=false;
		
		System.out.println("login:"+authentication.getName());
		
		Collection<?extends GrantedAuthority> roles=auth.getContext().getAuthentication().getAuthorities();
		
		for(GrantedAuthority temp:roles) {
			String role =temp.toString();
			System.out.println("role.........."+role);
			
			if(role.equalsIgnoreCase(accept)) {
				found=true;
			}
		}
		if(found) {
			
			Employee employee1=new Employee(id,name,jobRole,phNumber);
			employeeservice.add(employee1);
			return "Employee Added";
		}
		else {
			return "Access blocked";
		}
	}
	@PutMapping("/updateemployee")
	public String update(@RequestParam int id,@RequestParam String name,@RequestParam String jobRole,@RequestParam int phNumber,Authentication authentication,SecurityContextHolder auth) 
	{
		String accept="admin";
		boolean found=false;
		
		System.out.println("login:"+authentication.getName());
		
		Collection<?extends GrantedAuthority> granted=auth.getContext().getAuthentication().getAuthorities();
		
		for(GrantedAuthority temp:granted) {
			String role =temp.toString();
			System.out.println("role.............."+role);
			
			if(role.equalsIgnoreCase(accept)) {
				found=true;
			}
			
		}
		if(found) {
			Employee employee3=employeeservice.findById(id);
			employeeservice.update(employee3);
			return "Employee Updated";
		}
		else {
			return "Access blocked";
		}
	}
	
	@DeleteMapping("/delete")
	public String delete(@RequestParam int id,Authentication authentication,SecurityContextHolder auth) {
		 
		String accept="admin";
		boolean found=false;
		
		System.out.println("login:"+authentication.getName());
		
		Collection<?extends GrantedAuthority> granted=auth.getContext().getAuthentication().getAuthorities();
		
		for(GrantedAuthority temp:granted) {
			String role =temp.toString();
			System.out.println("role............"+role);
			
			if(role.equalsIgnoreCase(accept)) {
				found=true;
			}
			
		}
		if(found) {
			Employee employee4=new Employee(id,"","",0);
			employeeservice.delete(employee4);
			return "Employee Deleted";
		}
		else {
			return "Access blocked";
		}
	}
	
	@GetMapping("/sortemployee")
	public List<Employee> sort(@RequestParam String columns,@RequestParam Direction direction,Authentication authentication,SecurityContextHolder auth) {
		 
		String accept="admin";
		boolean found=false;
		
		System.out.println("login:"+authentication.getName());
		
		Collection<?extends GrantedAuthority> granted=auth.getContext().getAuthentication().getAuthorities();
		
		for(GrantedAuthority temp:granted) {
			String role =temp.toString();
			System.out.println("role..........."+role);
			
			if(role.equalsIgnoreCase(accept)) {
				found=true;
			}
		}
		if(found) {
			
			return employeeservice.getBySortOnly(columns, direction);
		}
		else {
			return null;
		}
	}
	
	@GetMapping("/searchemployee")
	public Employee search(@RequestParam int id,Authentication authentication,SecurityContextHolder auth) {
		 
		String accept="user";
		boolean found=false;
		
		System.out.println("login:"+authentication.getName());
		
		Collection<?extends GrantedAuthority> granted=auth.getContext().getAuthentication().getAuthorities();
		
		for(GrantedAuthority temp:granted) {
			String role =temp.toString();
			System.out.println("role..........."+role);
			
			if(role.equalsIgnoreCase(accept)) {
				found=true;
			}
		}
		if(found) {
			
			return employeeservice.findById(id);
		}
		else {
			return null;
		}
	}
	
}

